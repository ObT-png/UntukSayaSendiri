let { Schema, model } = require("mongoose")

let schema = new Schema({
    ChanelTesti: String,
    ChannelAutoStock: String,
    ChannelStock: String,
    MessageID: String,
    Delay: String,
    ChannelLeaderboard: String,
    MessagIDLeaderboard: String,
    DelayLeaderboard: String
});

let setchannel = model("setchannel", schema)

module.exports = setchannel