let {
    InteractionType,
    ButtonStyle,
    ActionRowBuilder,
    EmbedBuilder,
    MessageEmbed,
    ButtonBuilder,
} = require("discord.js");
let client = require('../../index');
let { CROWN, BALANCE, BOT, EARTH, Coin, WL, BGL, Warning, COLOR, imageUrl, DL, EmojiSaweria, EmojiTrakteer, Benar, Salah, ARROW, Kotak, EmojiBagiBagi } = require("../../config/configEmoji.json");
let Bal = require("../../Schema/balance.js");
let depo = require("../../Schema/depo.js");
let cd = new Map();

module.exports = {
    name: "ButtonMessage"
};

client.on("interactionCreate", async (interaction) => {
    if (interaction.customId === "balance1") {
        try {
            console.log(`[SYSTEM]`.bgRed.bold, `${interaction.user.username}`.bgCyan.bold, `Using Button Balance`.bgMagenta.bold);
            let user = interaction.user.id;
            let row6000 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji(BOT)
                    .setCustomId("growid23")
            );

            let wallet1 = await Bal.findOne({ DiscordID: user })
                .then((d) => {
                    return d;
                })
                .catch((e) => console.error(e));

            let lcd = cd.get(interaction.user.id);
            if (lcd && Date.now() < lcd) {
                let rt = Math.ceil((lcd - Date.now()) / 1000);
                return interaction.reply({
                    content: `*Just Wait **${rt} Seconds** Before Using The Button Again! ${Salah}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            cd.set(interaction.user.id, Date.now() + 5000)

            if (!wallet1) return interaction.reply({
                content: `*Set GrowID First Before Use This Button! ${Salah}*`,
                components: [row6000],
                ephemeral: true,
            }).catch((err) => console.error(err));

            let embed = new EmbedBuilder()
                .setTitle(`${CROWN} Balance Information ${CROWN}`)
                .setDescription(
                    `- *[${BOT}] GrowID: **${wallet1.GrowIDNow}***\n` +
                    `- *[${Coin}] Balance:**${wallet1.Balance == 0 ? ` 0 ${WL}` : `${Math.floor(wallet1.Balance / 10000) != 0 ? ` ${Math.floor(wallet1.Balance / 10000)} ${BGL}` : ``}${Math.floor((wallet1.Balance % 10000) / 100) != 0 ? ` ${Math.floor((wallet1.Balance % 10000) / 100)} ${DL}` : ``}${wallet1.Balance % 100 != 0 ? ` ${wallet1.Balance % 100} ${WL}` : ``}`}***\n` +
                    `- *[${BALANCE}] Total Deposit:**${wallet1.Deposit == 0 ? ` 0 ${WL}` : `${Math.floor(wallet1.Deposit / 10000) != 0 ? ` ${Math.floor(wallet1.Deposit / 10000)} ${BGL}` : ``}${Math.floor((wallet1.Deposit % 10000) / 100) != 0 ? ` ${Math.floor((wallet1.Deposit % 10000) / 100)} ${DL}` : ``}${wallet1.Deposit % 100 != 0 ? ` ${wallet1.Deposit % 100} ${WL}` : ``}`}***`
                )
                .setTimestamp()
                .setColor(COLOR)
                .setImage(imageUrl)
                .setFooter({
                    text: `This Is Your Balance ${interaction.user.username}`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
                });

            await interaction
                .reply({ embeds: [embed], ephemeral: true })
                .catch(console.error);
        } catch (error) {
            console.error(error);
        }
    }

    if (interaction.customId === "deposit") {
        try {
            console.log(`[SYSTEM]`.bgRed.bold, `${interaction.user.username}`.bgCyan.bold, `Using Button Deposit`.bgYellow.bold);
            let user = interaction.user.id;
            let row6000 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji(BOT)
                    .setCustomId("growid23")
            );

            let deposit = await depo
                .findOne({})
                .then((d) => {
                    return d;
                })
                .catch((e) => console.error(e));

            let wallet1 = await Bal.findOne({ DiscordID: user })
                .then((d) => {
                    return d;
                })
                .catch((e) => console.error(e));

            let lcd = cd.get(interaction.user.id);
            if (lcd && Date.now() < lcd) {
                let rt = Math.ceil((lcd - Date.now()) / 1000);
                return interaction.reply({
                    content: `*Just Wait **${rt} Seconds** Before Using The Button Again! ${Salah}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            cd.set(interaction.user.id, Date.now() + 5000)

            if (!wallet1) return interaction.reply({
                content: `*Set GrowID First Before Use This Button! ${Salah}*`,
                components: [row6000],
                ephemeral: true,
            }).catch((err) => console.error(err));

            if (!deposit) return interaction.reply({
                content: `*Please Set Your Deposit World First Using Commands /setdepo! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            if (!deposit?.ratedl) return interaction.reply({
                content: `*Tag Owner To Use Commands /ratedl For Set Rate DLS! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            let total = parseFloat(deposit.ratedl) * 100;
            let embed = new EmbedBuilder()
                .setTitle(`${CROWN} Deposit World ${CROWN}`)
                .setDescription(`${deposit?.world != "Not Set" ? `- [${EARTH}] *World: **${deposit.world}***` : ""}${deposit?.owner != "Not Set" ? `\n- [${CROWN}] *Owner: **${deposit.owner}***` : ""}${deposit?.botName != "Not Set" ? `\n- [${BOT}] *Bot Name: **${deposit.botName}***` : ""}${deposit?.saweria != "Not Set" ? `\n- [${EmojiSaweria}] *Saweria Link: **${deposit.saweria}***` : ""}${deposit?.Trakteer != "Not Set" ? `\n- [${EmojiTrakteer}] *Trakteer Link: **${deposit.Trakteer}***` : ""}${deposit?.BagiBagi != "Not Set" ? `\n- [${EmojiBagiBagi}] *Bagi-Bagi Link: **${deposit.BagiBagi}***` : ""}${deposit?.ratedl && deposit?.saweria != "Not Set" || deposit?.Trakteer != "Not Set" || deposit?.BagiBagi != "Not Set" ? `\n- [${DL}] *Rate DL: **${new Intl.NumberFormat().format(total)}***` : ""}`)
                .setTimestamp()
                .setImage(imageUrl)
                .setColor(COLOR)
                .setFooter({
                    text: `Note: Don't Donate If Bot Isnt The World`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
                });

            await interaction
                .reply({ embeds: [embed], ephemeral: true })
                .catch(console.error);
        } catch (error) {
            console.error(error);
        }
    }

    if (interaction.customId === "leaderboard") {
        try {
            let Data = ""
            await Bal.find({})
                .sort({ Balance: -1 })
                .limit(5)
                .then(async (data) => {
                    data.forEach((d, index) => {
                        Data += `*${CROWN} ${d.GrowIDNow} ${CROWN}\n${ARROW} Discord User: **<@${d.DiscordID}>** ${Benar}\n${ARROW} Total Buying Of Product: **${d.TotalBuying}** ${Kotak}\n${ARROW} Total Balance:**${d.Balance == 0 ? ` 0 ${WL}` : `${Math.floor(d.Balance / 10000) != 0 ? ` ${Math.floor(d.Balance / 10000)} ${BGL}` : ``}${Math.floor((d.Balance % 10000) / 100) != 0 ? ` ${Math.floor((d.Balance % 10000) / 100)} ${DL}` : ``}${d.Balance % 100 != 0 ? ` ${d.Balance % 100} ${WL}` : ``}`}**\n${ARROW} Total Deposit:**${d.Deposit == 0 ? ` 0 ${WL}` : `${Math.floor(d.Deposit / 10000) != 0 ? ` ${Math.floor(d.Deposit / 10000)} ${BGL}` : ``}${Math.floor((d.Deposit % 10000) / 100) != 0 ? ` ${Math.floor((d.Deposit % 10000) / 100)} ${DL}` : ``}${d.Deposit % 100 != 0 ? ` ${d.Deposit % 100} ${WL}` : ``}`}***\n\n`;
                    });
                });

            let embed = new EmbedBuilder()
                .setTitle(`${CROWN} Leaderboard Top 5 Player ${CROWN}`)
                .setDescription(Data)
                .setImage(imageUrl)
                .setColor(COLOR);

            await interaction.reply({
                embeds: [embed],
                ephemeral: true
            }).catch((err) => console.error(err));
        } catch (error) {
            console.error(error);
        }
    }

    if (interaction.customId === "growid1") {
        if (interaction.type !== InteractionType.ModalSubmit) return;
        try {
            let id = interaction.fields.getTextInputValue("growid");
            let correct = interaction.fields.getTextInputValue("confirm");

            let GrowID = id.toLowerCase();
            let user = interaction.user.id;

            if (!correct.includes(id)) return interaction.reply({
                content: `*Your GrowId Is Not Match!\nInput Again / Try Again ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            let checkuser = await Bal
                .findOne({ DiscordID: user })
                .then((d) => {
                    return d;
                })
                .catch(console.error);

            let existingEntry = await Bal.findOne({ GrowID: GrowID })
                .then((d) => {
                    return d?.DiscordID;
                })
                .catch((e) => console.error(e));

            if (existingEntry && existingEntry !== user) return interaction.reply({
                content: `*GrowID Is Already Used! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            if (existingEntry) {
                if (checkuser.GrowID == GrowID) return interaction.reply({
                    embeds: [{
                        description: `*GrowID Already Used By You! ${Salah}*`
                    }],
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            await Bal.findOneAndUpdate(
                { DiscordID: user },
                { $set: { GrowID: GrowID, GrowIDNow: id } },
                { upsert: true, new: true, setDefaultsOnInsert: true }
            ).then(async () => {
                if (!checkuser) {
                    await interaction.reply({
                        embeds: [{
                            description: `*Successfully Set Your GrowID to **${id}** ${Benar}*`
                        }],
                        ephemeral: true
                    }).catch((err) => console.error(err));
                } else {
                    await interaction.reply({
                        embeds: [{
                            description: `*Successfully Updated Your GrowID **${checkuser.GrowIDNow}** to **${id}** ${Benar}*`
                        }],
                        ephemeral: true
                    }).catch((err) => console.error(err));
                }
            }).catch((error) => console.error(error));
        } catch (error) {
            console.error(error);
        }
    }
})