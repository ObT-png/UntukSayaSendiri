let { Owner } = require("../../config/config.json");
let {
    InteractionType,
    ButtonStyle,
    ActionRowBuilder,
    EmbedBuilder,
    ButtonBuilder,
    MessageEmbed,
} = require("discord.js");
let Bal = require("../../Schema/balance.js");
let shop = require("../../Schema/shop.js");
let discount = require("../../Schema/discount.js");
let list = require("../../Schema/list.js");
let Price = require("../../Schema/price.js");
let order = require("../../Schema/order.js");
let client = require('../../index.js');
let ctesti = require("../../Schema/AllSettingChannel.js");
let cooldown = new Map();
let { Warning, Benar, WL, DL, BGL, ARROW, Loading, COLOR, CROWN, Megaphone, Salah, BALANCE, imageUrl, BOT } = require("../../config/configEmoji.json");

module.exports = {
    name: "Buying Item Of Menu"
};

client.on("interactionCreate", async (interaction) => {
    if (interaction.customId === "buys") {
        try {
            if (interaction.type !== InteractionType.ModalSubmit) return;
            let howmuch = interaction.fields.getTextInputValue("jumlah");
            let item = interaction.fields.getTextInputValue("code");
            let user = interaction.user;
            let userars = await client.users.fetch(Owner);
            let member = interaction.guild.members.cache.get(user.id);

            let lcd = cooldown.get(interaction.user.id);
            if (lcd && Date.now() < lcd) {
                let rt = Math.ceil((lcd - Date.now()) / 1000);
                return interaction.reply({
                    content: `*Just Wait **${rt} Seconds** Before Using The Button Again! ${Salah}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }
            cooldown.set(interaction.user.id, Date.now() + 60000)

            let discon = await discount
                .findOne({ code: item })
                .then((res) => {
                    return res;
                })
                .catch(console.error);

            let getCode = await list
                .findOne({ code: item })
                .then((res) => {
                    return res;
                })
                .catch(console.error);

            if (!getCode) return interaction.reply({
                content: `*Code Not Found ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            if (howmuch < 1) return interaction.reply({
                content: `*Use a Positif Number! ${Salah}*`,
                ephemeral: true,
            }).catch((err) => console.error(err));

            if (howmuch < Number(getCode.minimum)) return interaction.reply({
                content: `*Minimum Order The Products Is* **${getCode.minimum}**! ${Salah}`,
                ephemeral: true,
            }).catch((err) => console.error(err));

            if (isNaN(howmuch)) return interaction.reply({
                content: `*Only Use Number For Amount! ${Salah}*`,
                ephemeral: true,
            }).catch((err) => console.error(err));

            let row6050 = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji(BOT)
                    .setCustomId("growid23")
            );

            let getBal = await Bal.findOne({ DiscordID: user.id })
                .then((d) => {
                    return d;
                })
                .catch((e) => console.error(e));

            if (!getBal) return interaction.reply({
                content: `*Register First Before Using This Button! ${Salah}*`,
                components: [row6050],
                ephemeral: true,
            }).catch((err) => console.error(err));

            let pricao = await Price.findOne({ code: item })
                .then((d) => {
                    return d;
                })
                .catch((e) => console.error(e));

            let data = await shop
                .find({ code: item })
                .then((res) => {
                    return res;
                })
                .catch(console.error);

            if (data.length == 0) return interaction.reply({
                content: `*No Stock Yet! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            if (Number(data.length) < Number(howmuch)) return interaction.reply({
                content: `*Not That Much Stock! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            if (!pricao) return interaction.reply({
                content: `*Tag Owner To Set Price For Code **${item} ${Salah}***`,
                ephemeral: true
            }).catch((err) => console.error(err));

            let chaneltesti = await ctesti
                .findOne({})
                .then((d) => {
                    return d.ChanelTesti;
                })
                .catch((e) => console.error(e));

            let price = pricao.price;
            let wallet = getBal.Balance;
            let oprice = Number(price) * Number(howmuch);
            let testimoni = interaction.guild.channels.cache.get(chaneltesti);

            if (!discon) {
                if (wallet < oprice) return interaction.reply({
                    content: `*Our Money Is Less, The Price Is **${Math.floor(oprice / 10000)} ${BGL} ${Math.floor((oprice % 10000) / 100)} ${DL} ${oprice % 100} ${WL}** ${Salah}*`,
                    ephemeral: true,
                }).catch((err) => console.error(err));
            } else {
                let loprice = Number(discon.price) * Number(howmuch);
                if (wallet < loprice) return interaction.reply({
                    content: `*Our Money Is Less, The Price Is **${Math.floor(loprice / 10000)} ${BGL} ${Math.floor((loprice % 10000) / 100)} ${DL} ${loprice % 100} ${WL}** ${Salah}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            await interaction.reply({
                content: `***Proccessing Yourr Productt ${Loading}***`,
                ephemeral: true
            }).catch((err) => console.error(err));

            if (!discon) {
                await Bal.updateOne(
                    { DiscordID: user.id },
                    { $inc: { Balance: -Number(oprice), TotalBuying: howmuch } }
                ).catch((err) => console.error(err));
            } else {
                let loprice = Number(discon.price) * Number(howmuch);
                await Bal.updateOne(
                    { DiscordID: user.id },
                    { $inc: { Balance: -Number(loprice), TotalBuying: howmuch } }
                ).catch((err) => console.error(err));
            }

            let orderN = await order
                .findOneAndUpdate(
                    {},
                    { $inc: { Order: 1 } },
                    { upsert: true, new: true }
                )
                .then((d) => {
                    return d?.Order;
                })
                .catch(console.error);

            if (!orderN) orderN = 1;
            let sending = "";
            try {
                let dbstart = Date.now();
                if (!getCode.type.includes("script")) {
                    for (let i = 0; i < howmuch; i++) {
                        let send = await shop
                            .findOneAndDelete({ code: item })
                            .then((res) => {
                                console.log(`[COMMANDS]`.bgMagenta.bold, `Getting Your Data: ${res.data}`.green.bold);
                                return res;
                            })
                            .catch(console.error);
                        sending += send.data + "\n";
                    }
                } else {
                    let send = await shop
                        .findOne({ code: item })
                        .then((res) => {
                            return res;
                        })
                        .catch(console.error);
                    sending += send.data;
                }
                let dbfetchtime = (Date.now() - dbstart) / 1000;
                let basetime = Math.random() * (1.5 - 1.0) + 0.5;
                let lotime = (dbfetchtime + basetime).toFixed(3);
                console.log(dbfetchtime);

                await interaction.followUp({
                    content: `*Estimate Your Product Will be Send in **${lotime}s** ${Loading}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));

                if (!member.roles.cache.some((r) => r.id == getCode.role)) {
                    member.roles.add(getCode.role).catch((err) => console.error(err));
                }

                if (!discon) {
                    let testi = new EmbedBuilder()
                        .setTitle("#Order Number: " + orderN)
                        .setDescription(`${ARROW} Buyer: **<@${user.id}>**\n${ARROW} Product: **${howmuch} ${getCode?.name}**\n${ARROW} Total Price: **${Math.floor(oprice / 10000) != 0 ? `${Math.floor(oprice / 10000)} ${BGL}` : ``}${Math.floor((oprice % 10000) / 100) != 0 ? ` ${Math.floor((oprice % 10000) / 100)} ${DL}` : ``}${oprice % 100 != 0 ? ` ${oprice % 100} ${WL}` : ``}**\n\n**Thanks For Purchasing Our Product** ${Benar}`)
                        .setColor(COLOR)
                        .setTimestamp()
                        .setImage(imageUrl);

                    let buyed = new EmbedBuilder()
                        .setTitle(`${CROWN} Item Purchase Successffully ${CROWN}`)
                        .setDescription(`*${ARROW} Order Number: **${orderN}**\n${ARROW} Buyer: **<@${user.id}>**\n${ARROW} Product: **${howmuch} ${getCode?.name} ${Benar}**\n${ARROW} Total Price: **${Math.floor(oprice / 10000) != 0 ? `${Math.floor(oprice / 10000)} ${BGL}` : ``}${Math.floor((oprice % 10000) / 100) != 0 ? ` ${Math.floor((oprice % 10000) / 100)} ${DL}` : ``}${oprice % 100 != 0 ? ` ${oprice % 100} ${WL}` : ``}***`)
                        .setColor(COLOR)
                        .setTimestamp()
                        .setImage(imageUrl);

                    setTimeout(async () => {
                        user.send({
                            content: `*THIS IS YOUR ORDER FOR PRODUCT*`,
                            embeds: [buyed],
                            files: [
                                {
                                    attachment: Buffer.from(sending),
                                    name: `${interaction.user.username} Order.txt`,
                                },
                            ],
                        }).catch((err) => console.error(err));

                        await interaction.followUp({
                            content: `*This Your Order Sir!*\n# For More You Can Check The DIRECT MESSAGE!`,
                            files: [
                                {
                                    attachment: Buffer.from(sending),
                                    name: `${interaction.user.username} Order.txt`,
                                },
                            ],
                            ephemeral: true
                        }).catch((err) => console.error(err));

                        await testimoni.send({ embeds: [testi] }).catch((err) => console.error(err));
                    }, dbfetchtime * 1000);
                } else {
                    let loprice = Number(discon.price) * Number(howmuch);
                    let testis = new EmbedBuilder()
                        .setTitle("#Order Number: " + orderN)
                        .setDescription(`${ARROW} Buyer: **<@${user.id}>**\n${ARROW} Product: **${howmuch} ${getCode?.name}**\n${ARROW} Total Price: **${Math.floor(loprice / 10000) != 0 ? `${Math.floor(loprice / 10000)} ${BGL}` : ``}${Math.floor((loprice % 10000) / 100) != 0 ? ` ${Math.floor((loprice % 10000) / 100)} ${DL}` : ``}${loprice % 100 != 0 ? ` ${loprice % 100} ${WL}` : ``}**\n\n**Thanks For Purchasing Our Product** ${Benar}`)
                        .setColor(COLOR)
                        .setTimestamp()
                        .setImage(imageUrl);

                    let buyed = new EmbedBuilder()
                        .setTitle(`${CROWN} Item Purchase Successffully ${CROWN}`)
                        .setDescription(`*${ARROW} Order Number: **${orderN}**\n${ARROW} Buyer: **<@${user.id}>**\n${ARROW} Product: **${howmuch} ${getCode?.name} ${Benar}**\n${ARROW} Total Price: **${Math.floor(loprice / 10000) != 0 ? `${Math.floor(loprice / 10000)} ${BGL}` : ``}${Math.floor((loprice % 10000) / 100) != 0 ? ` ${Math.floor((loprice % 10000) / 100)} ${DL}` : ``}${loprice % 100 != 0 ? ` ${loprice % 100} ${WL}` : ``}***`)
                        .setColor(COLOR)
                        .setTimestamp()
                        .setImage(imageUrl);

                    setTimeout(async () => {
                        user.send({
                            content: `*THIS IS YOUR ORDER FOR PRODUCT*`,
                            embeds: [buyed],
                            files: [
                                {
                                    attachment: Buffer.from(sending),
                                    name: `${interaction.user.username} Order.txt`,
                                },
                            ],
                        }).catch((err) => console.error(err));

                        await interaction.followUp({
                            content: `*This Is Your Order!*\n# For More You Can Check The DIRECT MESSAGE!`,
                            files: [
                                {
                                    attachment: Buffer.from(sending),
                                    name: `${interaction.user.username} Order.txt`,
                                },
                            ],
                            ephemeral: true
                        }).catch((err) => console.error(err));

                        await testimoni.send({ embeds: [testis] }).catch((err) => console.error(err));
                    }, dbfetchtime * 1000);
                }

                userars.send({
                    content: `This Is <@${interaction.user.id}> Order`,
                    files: [
                        {
                            attachment: Buffer.from(sending),
                            name: `${interaction.user.username} Order.txt`,
                        },
                    ],
                }).catch((err) => console.error(err));

                await list.findOneAndUpdate(
                    { code: item },
                    { $inc: { sold: howmuch } },
                    { upsert: true, new: true }
                ).catch((err) => console.error(err));
            } catch (erorr) {
                await interaction.followUp({
                    content: "**Have Problem When Im Sending Your Order**\n*Contact the owner for get your order!!*",
                    ephemeral: true
                }).catch((err) => console.error(err));
                console.error(erorr);

                userars.send({
                    content: `**Please, Send This Product To ${interaction.user}**\n*Im Cannnot Send This Order For This User Because This User Disable a Direct Message*`,
                    files: [
                        {
                            attachment: Buffer.from(sending),
                            name: `${interaction.user.username} Order.txt`,
                        },
                    ],
                }).catch((err) => console.error(err));
            }
        } catch (error) {
            console.error(error);
        }
    }
})