let {
    ModalBuilder,
    TextInputBuilder,
    ActionRowBuilder,
    TextInputStyle,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
} = require("discord.js");
let client = require('../../index');
let Bal = require("../../Schema/balance.js");
let { BOT, Benar, Salah } = require("../../config/configEmoji.json");
let ctesti = require("../../Schema/AllSettingChannel.js");
let cd = new Map();

module.exports = {
    name: "Button Menu"
};

client.on("interactionCreate", async (interaction) => {
    if (interaction.customId === "Howmanys") {
        try {
            console.log(`[SYSTEM]`.bgRed.bold, `${interaction.user.username}`.bgCyan.bold, `Using Button BUY`.bgBlue.bold);
            let getBal = await Bal.findOne({ DiscordID: interaction.user.id })
                .then((d) => {
                    return d;
                })
                .catch((e) => console.error(e));

            let row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji(BOT)
                    .setCustomId("growid23")
            );

            let chaneltesti = await ctesti
                .findOne({})
                .then((d) => {
                    return d?.ChanelTesti;
                })
                .catch((e) => console.error(e));

            let lcd = cd.get(interaction.user.id);
            if (lcd && Date.now() < lcd) {
                let rt = Math.ceil((lcd - Date.now()) / 1000);
                return interaction.reply({
                    content: `*Just Wait **${rt} Seconds** Before Using The Button Again! ${Salah}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            cd.set(interaction.user.id, Date.now() + 20000)

            if (!getBal) {
                return interaction.reply({
                    content: `***Set Growid** First Before Using This Button! ${Salah}*`,
                    components: [row],
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            if (!chaneltesti) return interaction.reply({
                content: `*Feature Can't be Used Right Now\nJust Tag Owner For Setting Channel Testimoni! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));

            let buy = new ModalBuilder()
                .setCustomId("buys")
                .setTitle("BUYING ITEM");

            let code = new TextInputBuilder()
                .setCustomId("code")
                .setLabel("Code Of Products")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(10)
                .setMinLength(1)
                .setPlaceholder("Input Code Of Products Like You!")
                .setRequired(true);
            let row1 = new ActionRowBuilder().addComponents(code);

            let amount = new TextInputBuilder()
                .setCustomId("jumlah")
                .setLabel("Amount")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(4)
                .setMinLength(1)
                .setPlaceholder("Howmany do you want to buy?")
                .setValue("1")
                .setRequired(true);
            let row2 = new ActionRowBuilder().addComponents(amount);
            buy.addComponents(row1, row2);

            await interaction.showModal(buy);
        } catch (error) {
            console.error(error);
        }
    }

    if (interaction.customId === "growid23") {
        try {
            console.log(`[SYSTEM]`.bgRed.bold, `${interaction.user.username}`.bgCyan.bold, `Using Button Set GrowID`.bgYellow.bold);
            let lcd = cd.get(interaction.user.id);
            if (lcd && Date.now() < lcd) {
                let rt = Math.ceil((lcd - Date.now()) / 1000);
                return interaction.reply({
                    content: `*Just Wait **${rt} Seconds** Before Using The Button Again! ${Salah}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }

            cd.set(interaction.user.id, Date.now() + 10000)

            let growid = new ModalBuilder()
                .setCustomId("growid1")
                .setTitle("SET GROWID");

            let getgrowid = new TextInputBuilder()
                .setCustomId("growid")
                .setLabel("Input Your GrowID:")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(20)
                .setMinLength(2)
                .setPlaceholder("Input Your GrowID In Here And Make Sure It's Correct")
                .setRequired(true);
            let row3 = new ActionRowBuilder().addComponents(getgrowid);

            let confirm = new TextInputBuilder()
                .setCustomId("confirm")
                .setLabel("Confirm Your GrowID:")
                .setStyle(TextInputStyle.Short)
                .setMaxLength(20)
                .setMinLength(2)
                .setPlaceholder("Confirm Your GrowID Input Same Like Above!")
                .setRequired(true);
            let row4 = new ActionRowBuilder().addComponents(confirm);
            growid.addComponents(row3, row4);

            await interaction.showModal(growid);
        } catch (error) {
            console.error(error);
        }
    }
})