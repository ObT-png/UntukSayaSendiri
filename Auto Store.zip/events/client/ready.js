let client = require('../../index.js');
let {
    ActivityType,
    ButtonStyle,
    ActionRowBuilder,
    EmbedBuilder,
    MessageEmbed,
    ButtonBuilder,
} = require("discord.js");
let shop = require("../../Schema/shop.js");
let channelo = require("../../Schema/AllSettingChannel.js");
let mt = require("../../Schema/mt.js");
let order = require("../../Schema/order.js");
let depo = require("../../Schema/depo.js");
let Price = require("../../Schema/price.js");
let list = require("../../Schema/list.js");
let Bal = require("../../Schema/balance.js");
let { Benar, ARROW, Salah, Megaphone, WL, DL, BGL, CROWN, Duit, EARTH, BOT, imageUrl, COLOR, Watermark, Kotak } = require("../../config/configEmoji.json");
let Discount = require('../../Schema/discount.js');

module.exports = {
    name: "ready"
};

client.once("ready", async (client) => {
    try {
        let activities = [`type /help To See How To Buy`, `Auto Store by Wcuy`], i = 0;
        let chanel = await channelo
            .findOne({})
            .then((d) => {
                return d;
            })
            .catch(console.error());

        let checkdelay = chanel?.Delay ? chanel?.Delay : "60";
        let delayleader = chanel?.DelayLeaderboard ? chanel?.DelayLeaderboard : "60";
        setInterval(async () => {
            client.user.setPresence({
                activities: [{ name: `${activities[i++ % activities.length]}`, type: ActivityType.Custom }],
                status: "dnd",
            });

            let MT = await mt
                .findOne({})
                .then((d) => {
                    return d;
                })
                .catch(console.error);
            
            let deposit = await depo
                .findOne({})
                .then((d) => {
                    return d?.ratedl;
                })
                .catch((e) => console.error(e));

            let orderan = await order
                .findOne({})
                .then((d) => {
                    return d?.Order;
                })
                .catch((e) => console.error(e));

            let getCodes = await list
                .find({})
                .then((res) => {
                    return res;
                })
                .catch(console.error);
            if (getCodes.length < 1) return;
            let format = `<t:${Math.floor(new Date().getTime() / 1000)}:R>`;
            let text = "";
            let sold = "";
            let solding = 0;
            for (let i = 0; i < getCodes.length; i++) {
                let code = getCodes[i];
                let stock = await shop
                    .find({ code: code.code })
                    .then((res) => {
                        return res;
                    })
                    .catch(console.error);
                let price = await Price.findOne({ code: code.code })
                    .then((res) => {
                        return res;
                    })
                    .catch(console.error);
                let discount = await Discount.findOne({ code: code.code })
                    .then((res) => {
                        return res;
                    })
                    .catch(console.error);
                let haveStock = stock.length > 0;
                let emojis = haveStock ? Benar : Salah;
                let stockMessage = haveStock ? `${stock.length}` : "";
                solding += Number(code.sold);
                sold += `${ARROW} ${code.name} : **${code.sold}**\n`;
                text += `**--------------------------------------------**\n` +
                    `${CROWN} **${code.name}** ${CROWN}\n` +
                    `${ARROW} Code: **${code.code}**\n` +
                    `${code?.desc != "Not Set" ? `${ARROW} Description: **${code?.desc}**\n` : ""}` +
                    `${ARROW} Stock: **${stockMessage} ${emojis}**\n` +
                    `${ARROW} Price: **${discount ? `${price ? `${Math.floor(discount.price / 10000) != 0 ? ` ${Math.floor(discount.price / 10000)} ${BGL}` : ``}${Math.floor((discount.price % 10000) / 100) != 0 ? ` ${Math.floor((discount.price % 10000) / 100)} ${DL}` : ``}${discount.price % 100 != 0 ? ` ${discount.price % 100} ${WL}` : ``} *(${((price.price - discount.price) / price.price) * 100}%)*` : "Not Set Yet"}` : `${price ? `${Math.floor(price.price / 10000) != 0 ? ` ${Math.floor(price.price / 10000)} ${BGL}` : ``}${Math.floor((price.price % 10000) / 100) != 0 ? ` ${Math.floor((price.price % 10000) / 100)} ${DL}` : ``}${price.price % 100 != 0 ? ` ${price.price % 100} ${WL}` : ``}` : "Not Set Yet"}`}**\n`;
            }

            let embed = new EmbedBuilder()
                .setTitle(`${Megaphone} PRODUCT LIST ${Megaphone}`)
                .setDescription(`**Last Update: ${format}**\n${text}`)
                .setColor(COLOR)
                .setImage(imageUrl);

            let embed1 = new EmbedBuilder()
                .setTitle(`${CROWN} Statistic Stock ${CROWN}`)
                .setDescription(`*${ARROW} Total Order : **${orderan}**\n${ARROW} Total Purchase : **${solding}**\n${ARROW} RATE DL : ${deposit ? `**Rp${new Intl.NumberFormat().format(deposit * 100)}**/${DL}` : `Not Set Yet`}*\n**Purchases Product:**\n${sold}`)
                .setColor(COLOR)
                .setImage(imageUrl);

            let row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Buy")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<:emoji_72:1210797404731740181>")
                    .setCustomId("Howmanys"),
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:book431:1248246276022206485>")
                    .setCustomId("growid23"),
                new ButtonBuilder()
                    .setLabel("Balance")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:faq:1174339877333119068>")
                    .setCustomId("balance1"),
                new ButtonBuilder()
                    .setLabel("Deposit World")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:world:1174338186189733899>")
                    .setCustomId("deposit")
            );

            let rowmt = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Buy Product")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<:emoji_72:1210797404731740181>")
                    .setDisabled(true)
                    .setCustomId("Howmanys"),
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:book431:1248246276022206485>")
                    .setDisabled(true)
                    .setCustomId("growid23"),
                new ButtonBuilder()
                    .setLabel("Balance")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:faq:1174339877333119068>")
                    .setDisabled(true)
                    .setCustomId("balance1"),
                new ButtonBuilder()
                    .setLabel("Deposit World")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:world:1174338186189733899>")
                    .setDisabled(true)
                    .setCustomId("deposit")
            );

            let chanelas = await channelo
                .findOne({})
                .then((d) => {
                    return d;
                })
                .catch(console.error);

            if (chanel?.ChannelStock) {
                let channel = await client.channels.fetch(chanelas?.ChannelStock);
                let messageid = await channel.messages.fetch(chanelas?.MessageID);
                if (MT?.mt) {
                    await messageid.edit({
                        content: `**${Watermark}**`,
                        embeds: [embed1, embed],
                        components: [rowmt]
                    }).catch((err) => console.error(err));
                } else {
                    await messageid.edit({
                        content: `**${Watermark}**`,
                        embeds: [embed1, embed],
                        components: [row]
                    }).catch((err) => console.error(err));
                }
            }
        }, checkdelay * 1000);
        setInterval(async () => {
            let Data = "";
            let format = `<t:${Math.floor(new Date().getTime() / 1000)}:R>`;
            let MT = await mt
                .findOne({})
                .then((d) => {
                    return d?.mt;
                })
                .catch(console.error);

            let chanelas = await channelo
                .findOne({})
                .then((d) => {
                    return d;
                })
                .catch(console.error);

            await Bal.find({})
                .sort({ Balance: -1 })
                .limit(5)
                .then(async (data) => {
                    data.forEach((d, index) => {
                        Data += `*${CROWN} ${d.GrowIDNow} ${CROWN}\n${ARROW} Discord User: **<@${d.DiscordID}>** ${Benar}\n${ARROW} Total Buying Of Product: **${d.TotalBuying}** ${Kotak}\n${ARROW} Total Balance:**${d.Balance == 0 ? ` 0 ${WL}` : ` ${Math.floor(d.Balance / 10000) != 0 ? ` ${Math.floor(d.Balance / 10000)} ${BGL}` : ``}${Math.floor((d.Balance % 10000) / 100) != 0 ? ` ${Math.floor((d.Balance % 10000) / 100)} ${DL}` : ``}${d.Balance % 100 != 0 ? ` ${d.Balance % 100} ${WL}` : ``}`}**\n${ARROW} Total Deposit:**${d.Deposit == 0 ? ` 0 ${WL}` : ` ${Math.floor(d.Deposit / 10000) != 0 ? ` ${Math.floor(d.Deposit / 10000)} ${BGL}` : ``}${Math.floor((d.Deposit % 10000) / 100) != 0 ? ` ${Math.floor((d.Deposit % 10000) / 100)} ${DL}` : ``}${d.Deposit % 100 != 0 ? ` ${d.Deposit % 100} ${WL}` : ``}`}***\n\n`;
                    });
                });

            let embed = new EmbedBuilder()
                .setTitle(`${CROWN} Leaderboard Top 5 Player ${CROWN}`)
                .setDescription(`**Last Update: ${format}**\n\n${Data}`)
                .setColor(COLOR)
                .setImage(imageUrl);

            let row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:book431:1248246276022206485>")
                    .setCustomId("growid23"),
                new ButtonBuilder()
                    .setLabel("Balance")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:faq:1174339877333119068>")
                    .setCustomId("balance1"),
                new ButtonBuilder()
                    .setLabel("Leaderboard")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:world:1174338186189733899>")
                    .setCustomId("leaderboard")
            );

            let rowmt = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel("Set GrowID")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:book431:1248246276022206485>")
                    .setDisabled(true)
                    .setCustomId("growid23"),
                new ButtonBuilder()
                    .setLabel("Balance")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:faq:1174339877333119068>")
                    .setDisabled(true)
                    .setCustomId("balance1"),
                new ButtonBuilder()
                    .setLabel("Leaderboard")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji("<a:emoji_11:1172725434551644232>")
                    .setDisabled(true)
                    .setCustomId("leaderboard")
            );

            if (chanel?.ChannelLeaderboard) {
                let channel = await client.channels.fetch(chanelas?.ChannelLeaderboard);
                let messageid = await channel.messages.fetch(chanelas?.MessagIDLeaderboard);
                if (MT?.mt) {
                    await messageid.edit({
                        content: `**${Watermark}**`,
                        embeds: [embed],
                        components: [rowmt]
                    }).catch((err) => console.error(err));
                } else {
                    await messageid.edit({
                        content: `**${Watermark}**`,
                        embeds: [embed],
                        components: [row]
                    }).catch((err) => console.error(err));
                }
            }
        }, delayleader * 1000);
        console.log("----------------------------------------".yellow);
        console.log(`[READY]`.bgGreen.bold, `${client.user.tag} is up and ready to go.`.cyan.bold);
        console.log("----------------------------------------".yellow);
    } catch (err) {
        console.error(err);
    }
})