let { MessageEmbed, EmbedBuilder } = require('discord.js');
let client = require('../../index');
let Bal = require("../../Schema/balance.js");
let list = require("../../Schema/list.js");
let fs = require('fs');
let shop = require("../../Schema/shop.js");
let path = require('path');
let ctesti = require("../../Schema/AllSettingChannel.js");
let request = require("request");
let depos = require("../../Schema/depo.js");
let { WL, DL, BGL, Benar, Salah, CROWN, imageUrl, COLOR, ARROW, Warning } = require("../../config/configEmoji.json");
let watcher = {};
let { ChannelDonationLog, ChannelSaweriaLog, ChannelTrakteerLog, ChannelBagiBagi, AutoStockChannel, Owner, Admin } = require("../../config/config.json");

module.exports = {
    name: "Catch Of Donation Embeds"
};

client.on("messageCreate", async (message) => {
    if (message.channel.id === ChannelSaweriaLog) {
        if (message.embeds.length > 0) {
            let title = message.embeds[0].title;
            if (title) {
                let Deposito = title.match(/Senilai (.*)/);
                let GrowIdk = title.match(/Dari (.*) Senilai/);
                let depok = await depos
                    .findOne({})
                    .then((res) => {
                        return res?.ratedl;
                    })
                    .catch(console.error());

                if (Deposito) {
                    let growkids = GrowIdk[1];
                    let growIds = growkids.toLowerCase();
                    let depo = Deposito[1].replace(/\./g, '');

                    let wallet1 = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d;
                        })
                        .catch(console.error());

                    try {
                        if (!wallet1) return message.reply(`*User **${growkids}** Not Register In Database ${Salah}*`).catch((err) => console.error(err));
                        if (!depok) return message.reply(`*Owner do not set rate dl right now! ${Salah}*`).catch((err) => console.error(err));
                        let total = parseInt(depo / depok);

                        await Bal.updateOne(
                            { GrowID: growIds },
                            { $inc: { Balance: total, Deposit: total } }
                        );

                        let wallets = await Bal.findOne({ GrowID: growIds })
                            .then((d) => {
                                return d.Balance;
                            })
                            .catch(console.error());

                        let userars = await client.users.fetch(wallet1.DiscordID);
                        let embed = new EmbedBuilder()
                            .setDescription(`***${userars.username}'s** Donate **${Math.floor(total / 10000)} ${BGL} ${Math.floor((total % 10000) / 100)} ${DL} ${total % 100} ${WL}**\nNow Your Balance Is **${Math.floor(wallets / 10000)} ${BGL} ${Math.floor((wallets % 10000) / 100)} ${DL} ${wallets % 100} ${WL}** ${Benar}*`);

                        userars.send({ embeds: [embed] }).catch((err) => console.error(err));
                        await message.reply(`*Successfully Adding **${Math.floor(total / 10000)} ${BGL} ${Math.floor((total % 10000) / 100)} ${DL} ${total % 100} ${WL}** to **${growkids}** ${Benar}*`).catch((err) => console.error(err));
                    } catch (error) {
                        console.error("erorr", error);
                    }
                }
            }
        }
    }
    if (message.channel.id === ChannelBagiBagi) {
        if (message.embeds.length > 0) {
            let title = message.embeds[0].title;
            if (title) {
                let Deposito = title.match(/mengirim (.*) Koin/);
                let GrowIdk = title.match(/(.*) mengirim/);
                let depok = await depos
                    .findOne({})
                    .then((res) => {
                        return res?.ratedl;
                    })
                    .catch(console.error());

                if (Deposito) {
                    let growkids = GrowIdk[1];
                    let growIds = growkids.toLowerCase();
                    let depo = Deposito[1].replace(/\,/g, '');

                    let wallet1 = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d;
                        })
                        .catch(console.error());

                    try {
                        if (!wallet1) return message.reply(`*User **${growkids}** Not Register In Database ${Salah}*`).catch((err) => console.error(err));
                        if (!depok) return message.reply(`*Owner do not set rate dl right now! ${Salah}*`).catch((err) => console.error(err));
                        let total = parseInt(depo / depok);

                        await Bal.updateOne(
                            { GrowID: growIds },
                            { $inc: { Balance: total, Deposit: total } }
                        );

                        let wallets = await Bal.findOne({ GrowID: growIds })
                            .then((d) => {
                                return d.Balance;
                            })
                            .catch(console.error());

                        let userars = await client.users.fetch(wallet1.DiscordID);
                        let embed = new EmbedBuilder()
                            .setDescription(`***${userars.username}'s** Donate **${Math.floor(total / 10000)} ${BGL} ${Math.floor((total % 10000) / 100)} ${DL} ${total % 100} ${WL}**\nNow Your Balance Is **${Math.floor(wallets / 10000)} ${BGL} ${Math.floor((wallets % 10000) / 100)} ${DL} ${wallets % 100} ${WL}** ${Benar}*`);

                        userars.send({ embeds: [embed] }).catch((err) => console.error(err));
                        await message.reply(`*Successfully Adding **${Math.floor(total / 10000)} ${BGL} ${Math.floor((total % 10000) / 100)} ${DL} ${total % 100} ${WL}** to **${growkids}** ${Benar}*`).catch((err) => console.error(err));
                    } catch (error) {
                        console.error("erorr", error);
                    }
                }
            }
        }
    }
    if (message.channel.id === ChannelTrakteerLog) {
        if (message.embeds.length > 0) {
            let description = message.embeds[0].description;
            if (description) {
                let Deposite = description.match(/Senilai (.*)/);
                let Deposit = description.match(/(\w+) Mentraktir/);
                let depok = await depos
                    .findOne({})
                    .then((res) => {
                        return res?.ratedl;
                    })
                    .catch(console.error());

                if (Deposit && Deposite) {
                    let growId1 = Deposit[1];
                    let growIds = growId1.toLowerCase();
                    let depo = parseInt(Deposite[1]);

                    let wallet1 = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d;
                        });

                    try {
                        if (!wallet1) return message.reply(`*User **${growId1}** Not Register In Database ${Salah}*`).catch((err) => console.error(err));
                        if (!depok) return message.reply(`*Owner do not set rate dl right now! ${Salah}*`).catch((err) => console.error(err));
                        let total = parseInt(depo / depok);

                        await Bal.updateOne(
                            { GrowID: growIds },
                            { $inc: { Balance: total, Deposit: total } }
                        );

                        let wallets = await Bal.findOne({ GrowID: growIds })
                            .then((d) => {
                                return d.Balance;
                            });

                        let userars = await client.users.fetch(wallet1.DiscordID);
                        let embed = new EmbedBuilder()
                            .setDescription(`***${userars.username}'s** Donate **${Math.floor(total / 10000)} ${BGL} ${Math.floor((total % 10000) / 100)} ${DL} ${total % 100} ${WL}**\nNow Your Balance Is **${Math.floor(wallets / 10000)} ${BGL} ${Math.floor((wallets % 10000) / 100)} ${DL} ${wallets % 100} ${WL}** ${Benar}*`);

                        userars.send({ embeds: [embed] }).catch((err) => console.error(err));
                        await message.reply(`*Successfully Adding **${Math.floor(total / 10000)} ${BGL} ${Math.floor((total % 10000) / 100)} ${DL} ${total % 100} ${WL}** to **${growId1}** ${Benar}*`).catch((err) => console.error(err));
                    } catch (error) {
                        console.error("erorr", error);
                    }
                }
            }
        }
    }
    if (message.channel.id === ChannelDonationLog) {
        if (message.embeds.length > 0) {
            let description = message.embeds[0].description;
            if (description) {
                let GrowIDs = description.match(/GrowID: (\w+)/);
                let Deposita = description.match(/Amount: (\d+) (\w+)/);

                if (GrowIDs && Deposita) {
                    let growId = GrowIDs[1];
                    let growIds = growId.toLowerCase();
                    let depo = parseInt(Deposita[1]);
                    let item = Deposita[2];

                    let itemvalue = {
                        "WorldLock": 1,
                        "DiamondLock": 100,
                        "BlueGemLock": 10000,
                    };

                    let Lko = {
                        "WorldLock": `${WL}`,
                        "DiamondLock": `${DL}`,
                        "BlueGemLock": `${BGL}`,
                    }

                    let wallet1 = await Bal.findOne({ GrowID: growIds })
                        .then((d) => {
                            return d;
                        });

                    try {
                        if (!wallet1) return message.reply(`*User ${growId} Not Register In Database ${Salah}*`).catch((err) => console.error(err));
                        if (!itemvalue[item]) return message.reply(`*Unknown Item Name! ${Salah}*`).catch((err) => console.error(err));

                        let depoo = depo * itemvalue[item];
                        await Bal.updateOne(
                            { GrowID: growIds },
                            { $inc: { Balance: depoo, Deposit: depoo } }
                        );

                        let wallets = await Bal.findOne({ GrowID: growIds })
                            .then((d) => {
                                return d.Balance;
                            });

                        let userars = await client.users.fetch(wallet1.DiscordID);
                        userars.send(`*Successfully Adding **${depo} ${Lko[item]}** to **${growId}**\nYour New Balance Is **${Math.floor(wallets / 10000)} ${BGL} ${Math.floor((wallets % 10000) / 100)} ${DL} ${wallets % 100} ${WL}** ${Benar}*`).catch((err) => console.error(err));
                        await message.reply(`*Successfully Adding **${depo} ${Lko[item]}** to **${growId}**\nYour New Balance Is **${Math.floor(wallets / 10000)} ${BGL} ${Math.floor((wallets % 10000) / 100)} ${DL} ${wallets % 100} ${WL}** ${Benar}*`).catch((err) => console.error(err));
                    } catch (error) {
                        console.error("erorr", error);
                    }
                }
            }
        }
    }
    if (message.channel.id === AutoStockChannel) {
        if (message.content.startsWith('!addstock')) {
            if (!Admin.includes(message.author.id) && message.author.id !== Owner) return message.reply({ content: `***You do not allowed to use this commands! ${Salah}***` }).catch((err) => console.error(err));
            let args = message.content.slice(1).trim().split(/ +/);
            if (args.length < 2) return message.reply('Usage: !addstock <code> <stock1> <stock2> <stock3> <more unlimited>');
            let code = args[1];
            let items = args.slice(2).join(' ').split(/\s+/);

            let channelstock = await ctesti
                .findOne({})
                .then((d) => {
                    return d.ChannelAutoStock;
                })
                .catch((e) => console.error(e));

            let getCode = await list
                .findOne({ code: code })
                .then((d) => {
                    return d;
                })
                .catch(console.error);

            try {
                if (!channelstock) return message.reply({ content: `***Auto Channel Logs Doesn't Set Please Using Commands /setchannel for setting!***` }).catch((err) => console.error(err));
                if (!getCode) return message.reply({ content: `*Product With That Code Doesn't Exist ${Salah}*` }).catch((err) => console.error(err));
                let channel = client.channels.cache.get(channelstock);
                for (let item of items) {
                    let getdata = await shop
                        .findOne({ data: item })
                        .then((res) => {
                            return res;
                        })
                        .catch(console.error);

                    if (!getdata) {
                        await new shop({
                            code: code,
                            data: item,
                        })
                            .save()
                            .then(async (d) => {
                                console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                await message.channel.send({
                                    content: `*Successffully Adding Your Data: **${item}** ${Benar}*`
                                }).catch((err) => console.error(err));
                            })
                            .catch(console.error);
                    } else {
                        await message.channel.send({
                            content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*`
                        }).catch((err) => console.error(err));
                        console.log(`[COMMANDS]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                    }
                };
                let stock = await shop
                    .find({ code: code })
                    .then((res) => {
                        return res;
                    })
                    .catch(console.error);

                let embed = new EmbedBuilder()
                    .setTitle(`${CROWN} RESTOCK NOTIFICATION ${CROWN}`)
                    .setDescription(`*${ARROW} Product Name: **${getCode.name}**\n${ARROW} Product Code: **${code}**\n${ARROW} New Stock: **${stock.length}**\n\n${Warning} HAS BEEN RESTOCKED WITH **${items.length}** NEW STOCK! ${Warning}*`)
                    .setImage(imageUrl)
                    .setColor(COLOR)
                    .setTimestamp()
                    .setFooter({
                        text: `Auto Store by ObT`,
                        iconURL: message.author.displayAvatarURL({ dynamic: true }),
                    });
                await channel.send({ embeds: [embed] }).catch((err) => console.error(err));
            } catch (error) {
                console.error("erorr", error);
            }
        } else if (message.content.startsWith('!addfile')) {
            if (!Admin.includes(message.author.id) && message.author.id !== Owner) return message.reply({ content: `***You do not allowed to use this commands! ${Salah}***` }).catch((err) => console.error(err));
            let args = message.content.slice(1).trim().split(/ +/);
            if (args.length < 2) return message.reply('Usage: !addstock <code> <file>');
            let code = args[1];
            let attachments = message.attachments;
            if (attachments.size === 0) return message.reply('Please attach a file with this command.');

            let channelstock = await ctesti
                .findOne({})
                .then((d) => {
                    return d.ChannelAutoStock;
                })
                .catch((e) => console.error(e));

            let getCode = await list
                .findOne({ code: code })
                .then((d) => {
                    return d;
                })
                .catch(console.error);

            try {
                if (!channelstock) return message.reply({ content: `***Auto Channel Logs Doesn't Set Please Using Commands /setchannel for setting!***` }).catch((err) => console.error(err));
                if (!getCode) return message.reply({ content: `*Product With That Code Doesn't Exist ${Salah}*` }).catch((err) => console.error(err));
                let attachment = attachments.first();
                let channel = client.channels.cache.get(channelstock);
                request(attachment.url, async (err, res, body) => {
                    if (err) return console.error(err);
                    let items = body.split(/[\n\r\s]+/);
                    if (items.length == 0) return message.reply({ content: `*No Item In This File!*`, ephemeral: true })
                    for (let item of items) {
                        let getdata = await shop
                            .findOne({ data: item })
                            .then((res) => {
                                return res;
                            })
                            .catch(console.error);

                        if (!getdata) {
                            await new shop({
                                code: code,
                                data: item,
                            })
                                .save()
                                .then(async (d) => {
                                    console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                    await message.channel.send({
                                        content: `*Write File Succesffully and Added Into the MongoDB: **${item}** ${Benar}*`,
                                        ephemeral: true
                                    }).catch((err) => console.error(err));
                                })
                                .catch(console.error);
                        } else {
                            await message.channel.send({
                                content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*`,
                                ephemeral: true
                            }).catch((err) => console.error(err));
                            console.log(`[COMMANDS]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                        }
                    }
                    let stock = await shop
                        .find({ code: code })
                        .then((res) => {
                            return res;
                        })
                        .catch(console.error);

                    let embed = new EmbedBuilder()
                        .setTitle(`${CROWN} RESTOCK NOTIFICATION ${CROWN}`)
                        .setDescription(`*${ARROW} Product Name: **${getCode.name}**\n${ARROW} Product Code: **${code}**\n${ARROW} New Stock: **${stock.length}**\n\n${Warning} HAS BEEN RESTOCKED WITH **${items.length}** NEW STOCK! ${Warning}*`)
                        .setImage(imageUrl)
                        .setColor(COLOR)
                        .setTimestamp()
                        .setFooter({
                            text: `Auto Store by ObT`,
                            iconURL: message.author.displayAvatarURL({ dynamic: true }),
                        });
                    await channel.send({ embeds: [embed] }).catch((err) => console.error(err));
                });
            } catch (error) {
                console.error("erorr", error);
            }
        } else if (message.content.startsWith('!autostock')) {
            if (!Admin.includes(message.author.id) && message.author.id !== Owner) return message.reply({ content: `***You do not allowed to use this commands! ${Salah}***` }).catch((err) => console.error(err));
            let args = message.content.slice(1).trim().split(/ +/);
            if (args.length < 3 || args.length > 3) return message.reply('Usage: !autostock <code> <locating file>').catch((err) => console.error(err));
            let code = args[1];
            if (!code) return message.reply(`***Silakan berikan path file untuk dihentikan Auto Stocknya. Contoh: !autostock <code> <locating file> ${Salah}***`);
            let filePath = args[2];
            if (!filePath) return message.reply(`***Silakan berikan path file untuk dihentikan Auto Stocknya. Contoh: !autostock <code> D:\\FOLDER\\HAHO.txt ${Salah}***`);

            let channelstock = await ctesti
                .findOne({})
                .then((d) => {
                    return d.ChannelAutoStock;
                })
                .catch((e) => console.error(e));

            let getCode = await list
                .findOne({ code: code })
                .then((d) => {
                    return d;
                })
                .catch(console.error);

            try {
                if (!channelstock) return message.reply({ content: `***Auto Channel Logs Doesn't Set Please Using Commands /setchannel for setting!***` }).catch((err) => console.error(err));
                if (!getCode) return message.reply({ content: `*Product With That Code Doesn't Exist ${Salah}*` }).catch((err) => console.error(err));
                if (!fs.existsSync(filePath)) return message.reply(`***File Tidak Di Temukan ${Salah}***`).catch((err) => console.error(err));
                if (watcher[filePath]) return message.reply(`***Auto Stock Telah Berjalan... ${Benar}***`).catch((err) => console.error(err));
                message.reply(`***Memulai Auto Stock... ${Benar}***`).catch((err) => console.error(err));
                watcher[filePath] = fs.watch(filePath, (eventType) => {
                    if (eventType === 'change') {
                        console.log(`[AUTOSTOCK]`.bgMagenta.bold, `FILE TELAH DI UBAH!`.green.bold);
                        fs.readFile(filePath, 'utf8', async (err, data) => {
                            if (err) return console.log(`[AUTOSTOCK]`.bgMagenta.bold, `Terjadi kesalahan saat membaca file: ${err}`.red.bold);
                            if (data.trim() === '') return console.log(`[AUTOSTOCK]`.bgMagenta.bold, `File Kosong Tidak Ada Data Yang Di Ambil`.red.bold);
                            let channel = client.channels.cache.get(AutoStockChannel);
                            let channels = client.channels.cache.get(channelstock);
                            if (channel) {
                                let items = data.split(/[\n\r\s]+/);
                                if (items.length == 0) return channel.send({ content: `*No Item In This File! ${Salah}*` }).catch((err) => console.error(err));
                                for (let item of items) {
                                    let getdata = await shop
                                        .findOne({ data: item })
                                        .then((res) => {
                                            return res;
                                        })
                                        .catch(console.error);

                                    if (!getdata) {
                                        await new shop({
                                            code: code,
                                            data: item,
                                        })
                                            .save()
                                            .then(async (d) => {
                                                console.log(`[AUTOSTOCK]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                                await channel.send({ content: `*Write File Succesffully and Added Into the MongoDB: **${item}** ${Benar}*` }).catch((err) => console.error(err));
                                            })
                                            .catch(console.error);
                                    } else {
                                        await channel.send({ content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*` }).catch((err) => console.error(err));
                                        console.log(`[AUTOSTOCK]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                                    }
                                }
                                let stock = await shop
                                    .find({ code: code })
                                    .then((res) => {
                                        return res;
                                    })
                                    .catch(console.error);

                                let embed = new EmbedBuilder()
                                    .setTitle(`${CROWN} RESTOCK NOTIFICATION ${CROWN}`)
                                    .setDescription(`*${ARROW} Product Name: **${getCode.name}**\n${ARROW} Product Code: **${code}**\n${ARROW} New Stock: **${stock.length}**\n\n${Warning} HAS BEEN RESTOCKED WITH **${items.length}** NEW STOCK! ${Warning}*`)
                                    .setImage(imageUrl)
                                    .setColor(COLOR)
                                    .setTimestamp()
                                    .setFooter({
                                        text: `Auto Store by ObT`,
                                        iconURL: message.author.displayAvatarURL({ dynamic: true }),
                                    });
                                await channels.send({ embeds: [embed] }).catch((err) => console.error(err));
                            } else {
                                console.log(`[AUTOSTOCK]`.bgMagenta.bold, `ChannelID Tidak DI Temukan Please Correct This!!`.red.bold);
                            }
                            fs.writeFile(filePath, '', (err) => {
                                if (err) {
                                    console.log(`[AUTOSTOCK]`.bgMagenta.bold, `Terjadi kesalahan saat mengosongkan file: ${err}`.red.bold);
                                } else {
                                    console.log(`[AUTOSTOCK]`.bgMagenta.bold, `Isi File Berhasil Di Kosongkan!`.green.bold);
                                }
                            });
                        });
                    }
                });
            } catch (error) {
                console.error("erorr", error);
            }
        } else if (message.content.startsWith('!removeautostock')) {
            if (!Admin.includes(message.author.id) && message.author.id !== Owner) return message.reply({ content: `***You do not allowed to use this commands! ${Salah}***` }).catch((err) => console.error(err));
            let args = message.content.split(' ');
            let filePath = args[1];
            if (!filePath) return message.reply(`***Silakan berikan path file untuk dihentikan Auto Stocknya. Contoh: !removeautostock D:\\FOLDER\\HAHO.txt ${Salah}***`);
            if (!watcher[filePath]) return message.reply(`*File ini tidak sedang dipantau: **${filePath}** ${Salah}*`);

            watcher[filePath].close();
            delete watcher[filePath];
            message.reply(`*Auto Stock Telah Di Hentikan: **${filePath}** ${Benar}*`).catch((err) => console.error(err));
            console.log(`[AUTOSTOCK]`.bgMagenta.bold, `Auto Stock Di Hentikan: ${filePath}`.green.bold);
        } else if (message.content.startsWith('!listautostock')) {
            if (!Admin.includes(message.author.id) && message.author.id !== Owner) return message.reply({ content: `***You do not allowed to use this commands! ${Salah}***` }).catch((err) => console.error(err));
            let watchedFiles = Object.keys(watcher);
            if (watchedFiles.length === 0) {
                message.reply(`***Tidak ada file yang sedang dipantau. ${Salah}***`);
            } else {
                message.reply(`*File yang sedang dipantau:\n**${watchedFiles.join('\n')}***`);
            }
        }
    }
})