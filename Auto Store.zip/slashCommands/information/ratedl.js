let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ApplicationCommandOptionType,
} = require("discord.js")
let depo = require("../../Schema/depo.js");
let { Owner } = require("../../config/config.json");
let { COLOR, Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'setdl',
    description: "Set Rate DL For Payment QRIS",
    accessableby: "admin",
    options: [
        {
            name: "ratedl",
            description: "Rate DL Now!",
            type: ApplicationCommandOptionType.Number,
            required: true,
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let amount = interaction.options.getNumber("ratedl");
        let total = amount / 100;
        let user = await client.users.fetch(Owner);

        if (isNaN(amount)) return interaction.reply({
            content: `*Only Using Number! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await depo.findOneAndUpdate(
            {},
            { $set: { ratedl: total } },
            { upsert: true, new: true }
        )
            .then(async (res) => {
                await interaction.reply({
                    content: `*Successfully Set Rate DL To **${parseFloat(amount)} ${Benar}***`,
                    ephemeral: true
                }).catch((err) => console.error(err));

                let sendToOwner = new EmbedBuilder()
                    .setTitle("Rate DL History")
                    .setDescription(`*Successfully Set Rate DL To **${parseFloat(amount)} ${Benar}***`)
                    .setTimestamp()
                    .setColor(COLOR);
                user.send({ embeds: [sendToOwner] }).catch((err) => console.error(err));
            })
            .catch(console.error);
    }
}