const { TicTacToe } = require('discord-gamecord');
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('tic-tac-toe')
    .setDescription('Play a game of Tic Tac Toe on Discord!')
    .addUserOption(option => option.setName('user').setDescription('Select a user to play the game with!').setRequired(true)),

    async execute (interaction) {
        const Game = new TicTacToe({
            message: interaction,
            isSlashGame: true,
            opponent: interaction.options.getUser('user'),
            embed: {
                title: 'Tic Tac Toe!',
                color: '#575757',
                statusTitle: 'Status',
                overTitle: 'Game Over!'
            },

            emojis: {
                xButton: '✖️',
                oButton: '⭕',
                blankButton: '➖'
            },

            mentionUser: true,
            timeoutTime: 60000,
            xButtonStyle: 'DANGER',
            oButtonStyle: 'PRIMARY',
            turnMessage: "{emoji} | It's your turn, **{player}**",
            winMessage: "{emoji} | **{player}** has won the TicTacToe Game!",
            tieMessage: 'The game has tied! No one won the Tic Tac Toe game. :(',
            timeoutMessage: 'The game concluded after inactivity! No one won the game.',
            playerOnlyMessage: 'Only {player} and {opponent} can interact with the current game!'
        });

        Game.startGame();
        Game.on('gameover', result => {
            return;

        })
    }
}