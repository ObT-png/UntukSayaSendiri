let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let list = require("../../Schema/list.js");
let { Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'changename',
    description: "Change Name Of Product",
    accessableby: "admin",
    options: [
        {
            name: "code",
            description: "Code Of Product",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "name",
            description: "New Name For Product",
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let code = interaction.options.getString("code");
        let productName = interaction.options.getString("name");

        let getCode = await list
            .findOne({ code: code })
            .then((d) => {
                return d;
            })
            .catch(console.error);

        if (!getCode) return interaction.reply({
            content: `*Product With That Code Doesn't Exist ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await list.findOneAndUpdate({ code: code }, { $set: { name: productName }})
            .then(async (d) => {
                await interaction.reply({
                    content: `*Product Name **${getCode.name}** Changed To **${productName} ${Benar}***`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            })
            .catch(console.error);
    }
}