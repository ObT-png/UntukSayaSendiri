let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let Bal = require("../../Schema/balance.js");
let { Owner } = require("../../config/config.json");
let { Loading, Benar, Salah, WL, DL, BGL } = require("../../config/configEmoji.json");
module.exports = {
    name: 'removebalance',
    description: "remove balance to user",
    accessableby: "admin",
    options: [
        {
            name: "user",
            description: "User To Add Balance",
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: "balance",
            description: "how many balance?",
            type: ApplicationCommandOptionType.Number,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let growId1 = interaction.options.getUser("user");
        let Balance = interaction.options.getNumber("balance");
        let growId = growId1.id;
        let userars = await client.users.fetch(Owner);
        let wallet1 = await Bal.findOne({ DiscordID: growId })
            .then((d) => {
                return d;
            })
            .catch((e) => console.error(e));

        if (!wallet1) return interaction.reply({
            content: `*The user do not have growid right now! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        if (Balance < 1) return interaction.reply({
            content: `*Use a Positif Number! ${Salah}*`,
            ephemeral: true,
        }).catch((err) => console.error(err));

        await Bal.updateOne({ DiscordID: growId }, { $inc: { Balance: -Balance } })
            .then(async (res) => {
                await interaction.reply({ content: `***${Math.floor(Balance / 10000)} ${BGL} ${Math.floor((Balance % 10000) / 100)} ${DL} ${Balance % 100} ${WL}** Balance Removed To <@${growId}> ${Benar}*`, ephemeral: true }).catch((err) => console.error(err));
                let sendToOwner = new EmbedBuilder()
                    .setTitle("Removed Balance History")
                    .setDescription(`- User:** <@${wallet1.DiscordID}>**\n- Amount: ***${Math.floor(Balance / 10000)} ${BGL} ${Math.floor((Balance % 10000) / 100)} ${DL} ${Balance % 100} ${WL}***`)
                    .setTimestamp();
                userars.send({ embeds: [sendToOwner] }).catch((err) => console.error(err));
            }).catch((err) => console.error(err));
    }
}