let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ApplicationCommandOptionType,
} = require("discord.js");
let list = require("../../Schema/list.js");
let Price = require("../../Schema/price.js");
let { Owner } = require("../../config/config.json");
let { Loading, Benar, Salah, WL, DL, BGL } = require("../../config/configEmoji.json");
module.exports = {
    name: 'setprice',
    description: "Set Price For Product",
    accessableby: "admin",
    options: [
        {
            name: "code",
            description: "Code Of Product",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "price",
            description: "Howmany Price To Add In Product?",
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let code = interaction.options.getString("code");
        let price = interaction.options.getString("price");
        let prices = parseFloat(price);
        let user = await client.users.fetch(Owner);
        let getCode = await list
            .findOne({ code: code })
            .then((res) => {
                return res;
            })
            .catch(console.error);

        if (!getCode) return interaction.reply({
            content: `*Code Not Found ${Benar}*`,
            ephemeral: true
        });

        if (!isNaN(price)) {
            await Price.findOneAndUpdate(
                { code: code },
                { price: prices },
                { upsert: true, new: true }
            ).then(async (res) => {
                await interaction.reply({
                    content: `*Successffully Set **${code}** Price With Price **${Math.floor(price / 10000)} ${BGL} ${Math.floor((price % 10000) / 100)} ${DL} ${price % 100} ${WL} ${Benar}***`,
                    ephemeral: true
                }).catch((err) => console.error(err));
                let sendToOwner = new EmbedBuilder()
                    .setTitle("Price History")
                    .setDescription(`- Code: **${code}**\n- New Price: **${Math.floor(price / 10000)} ${BGL} ${Math.floor((price % 10000) / 100)} ${DL} ${price % 100} ${WL}**`)
                    .setTimestamp();
                user.send({ embeds: [sendToOwner] }).catch((err) => console.error(err));
            })
            .catch(console.error);
        }
    }
}