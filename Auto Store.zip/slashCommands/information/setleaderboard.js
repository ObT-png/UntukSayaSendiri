let {
    ActivityType,
    ButtonStyle,
    ActionRowBuilder,
    EmbedBuilder,
    MessageEmbed,
    ApplicationCommandOptionType,
    ButtonBuilder,
} = require("discord.js");
let shop = require("../../Schema/shop.js");
let channelo = require("../../Schema/AllSettingChannel.js");
let mt = require("../../Schema/mt.js");
let Bal = require("../../Schema/balance.js");
let order = require("../../Schema/order.js");
let list = require("../../Schema/list.js");
let { Warning, Benar, ARROW, Salah, WL, CROWN, DL, BGL, imageUrl, COLOR, Watermark, Kotak } = require("../../config/configEmoji.json");
let Discount = require('../../Schema/discount.js');

module.exports = {
    name: 'setleaderboard',
    description: "sending realtime product",
    accessableby: "admin",
    options: [
        {
            name: "channel",
            description: "Select Your Server To Send Realtime!",
            type: ApplicationCommandOptionType.Channel,
            required: true
        },
        {
            name: "delay",
            description: "Delay For Seconds/Detik",
            type: ApplicationCommandOptionType.Number,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let delay = interaction.options.getNumber("delay");
        let channel = interaction.options.getChannel("channel");
        let ChanelID = interaction.guild.channels.cache.get(`${channel.id}`);

        if (!ChanelID.viewable) {
            return interaction.reply({
                content: `*The provided channel is not visible to me! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));
        }

        if (delay < 30 || delay > 120) return interaction.reply({
            content: `*Minimum Delay For Realtime Is 30 Seconds And Max Delay 120 Seconds/2 Minutes ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        let chanel = await channelo
            .findOne({})
            .then((d) => {
                return d?.ChannelLeaderboard;
            })
            .catch(console.error());

        let getCodesa = await list
            .find({})
            .then((res) => {
                return res;
            })
            .catch(console.error);

        if (getCodesa.length < 1) return interaction.reply({
            content: `*/addproduct first before use this commands! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await interaction.reply({
            content: `*Started Editing The Realtime Leaderboard Delay **${delay}s ${Benar}***`,
            ephemeral: true
        }).catch((err) => console.error(err));

        let sat = await channel.send({
            content: `*Started Editing The Realtime Learderboard Delay **${delay}s ${Benar}***`
        }).catch((err) => console.error(err));

        await channelo.findOneAndUpdate(
            {},
            { $set: { ChannelLeaderboard: ChanelID, MessagIDLeaderboard: sat.id, DelayLeaderboard: delay } },
            { upsert: true, new: true }
        );

        try {
            if (!chanel) {
                setInterval(async () => {
                    let Data = "";
                    let format = `<t:${Math.floor(new Date().getTime() / 1000)}:R>`;
                    let MT = await mt
                        .findOne({})
                        .then((d) => {
                            return d?.mt;
                        })
                        .catch(console.error);

                    await Bal.find({})
                        .sort({ Balance: -1 })
                        .limit(5)
                        .then(async (data) => {
                            data.forEach((d, index) => {
                                Data += `*${CROWN} ${d.GrowIDNow} ${CROWN}\n${ARROW} Discord User: **<@${d.DiscordID}>** ${Benar}\n${ARROW} Total Buying Of Product: **${d.TotalBuying}** ${Kotak}\n${ARROW} Total Balance:**${d.Balance == 0 ? ` 0 ${WL}` : ` ${Math.floor(d.Balance / 10000) != 0 ? `${Math.floor(d.Balance / 10000)} ${BGL}` : ``}${Math.floor((d.Balance % 10000) / 100) != 0 ? ` ${Math.floor((d.Balance % 10000) / 100)} ${DL}` : ``}${d.Balance % 100 != 0 ? ` ${d.Balance % 100} ${WL}` : ``}`}**\n${ARROW} Total Deposit:**${d.Deposit == 0 ? ` 0 ${WL}` : `${Math.floor(d.Deposit / 10000) != 0 ? ` ${Math.floor(d.Deposit / 10000)} ${BGL}` : ``}${Math.floor((d.Deposit % 10000) / 100) != 0 ? ` ${Math.floor((d.Deposit % 10000) / 100)} ${DL}` : ``}${d.Balance % 100 != 0 ? ` ${d.Deposit % 100} ${WL}` : ``}`}***\n\n`;
                            });
                        });

                    let embed = new EmbedBuilder()
                        .setTitle(`${CROWN} Leaderboard Top 5 Player ${CROWN}`)
                        .setDescription(`**Last Update: ${format}**\n${Data}`)
                        .setColor(COLOR)
                        .setImage(imageUrl);

                    let row2 = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel("Set GrowID")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:book431:1248246276022206485>")
                            .setCustomId("growid23"),
                        new ButtonBuilder()
                            .setLabel("Balance")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:faq:1174339877333119068>")
                            .setCustomId("balance1"),
                        new ButtonBuilder()
                            .setLabel("Leaderboard")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:world:1174338186189733899>")
                            .setCustomId("leaderboard")
                    );

                    let rowmt = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel("Set GrowID")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:book431:1248246276022206485>")
                            .setDisabled(true)
                            .setCustomId("growid23"),
                        new ButtonBuilder()
                            .setLabel("Balance")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:faq:1174339877333119068>")
                            .setDisabled(true)
                            .setCustomId("balance1"),
                        new ButtonBuilder()
                            .setLabel("Leaderboard")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:emoji_11:1172725434551644232>")
                            .setDisabled(true)
                            .setCustomId("leaderboard")
                    );

                    if (MT) {
                        await sat.edit({
                            content: `**${Watermark}**`,
                            embeds: [embed],
                            components: [rowmt]
                        }).catch((err) => console.error(err));
                    } else {
                        await sat.edit({
                            content: `**${Watermark}**`,
                            embeds: [embed],
                            components: [row2]
                        }).catch((err) => console.error(err));
                    }
                }, delay * 1000);
            }
        } catch (err) {
            console.error(err);
        }
    }
}