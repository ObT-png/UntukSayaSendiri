let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let list = require("../../Schema/list.js");
let { Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'changerole',
    description: "Change Role Of Product",
    accessableby: "admin",
    options: [
        {
            name: "code",
            description: "Code Of Product",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "role",
            description: "Tag Role For Change Role",
            type: ApplicationCommandOptionType.Role,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let code = interaction.options.getString("code");
        let productRoles = interaction.options.getRole("role");
        let productRole = productRoles.id;
        let guild = client.guilds.cache.get(interaction.guild.id);

        let getCode = await list
            .findOne({ code: code })
            .then((d) => {
                return d;
            })
            .catch(console.error);

        if (!getCode) return interaction.reply({
            content: `*Product With That Code Doesnt Exit! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await list.findOneAndUpdate({ code: code }, { $set: { role: productRole }})
            .then(async (d) => {
                let role = guild.roles.cache.get(getCode.role);
                await interaction.reply({
                    content: `*Role has been Changed **${role}** To **${productRoles} ${Benar}***`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            })
            .catch(console.error);
    }
}