let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let list = require("../../Schema/list.js");
let { Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'removeproduct',
    description: "Remove Product From Stock List",
    accessableby: "admin",
    options: [
        {
            name: "code",
            description: "Code Of Product",
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let code = interaction.options.getString("code");
        let getCode = await list
            .findOne({ code: code })
            .then((res) => {
                return res;
            })
            .catch(console.error);

        if (!getCode) return interaction.reply({
            content: `*Product With That Code Doesnt Exist! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await list.deleteOne({ code: code })
            .then(async (d) => {
                await interaction.reply({
                    content: `*Product has been removed In Code **${code}** ${Benar}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));
            })
            .catch(console.error);
    }
}