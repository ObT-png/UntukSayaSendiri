let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let depo = require("../../Schema/depo.js")
let { Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'setdepo',
    description: "Set World Deposit",
    accessableby: "admin",
    options: [
        {
            name: "world",
            description: "World Deposit",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "owner",
            description: "Nama Owner World Depo",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "botname",
            description: "Name Of Bot Depo",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "saweria",
            description: "Put The Link For Donate Saweria!",
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: "trakteer",
            description: "Put The Link For Donate Trakteer!",
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: "bagibagi",
            description: "Put The Link For Donate BagiBagi!",
            type: ApplicationCommandOptionType.String,
            required: false
        },
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let world = interaction.options.getString("world");
        let owner = interaction.options.getString("owner");
        let botName = interaction.options.getString("botname");
        let sawerias = interaction.options.getString("saweria");
        let trakteers = interaction.options.getString("trakteer");
        let bagi = interaction.options.getString("bagibagi");
        let worlds = world ? world : "Not Set";
        let owners = owner ? owner : "Not Set";
        let botnames = botName ? botName : "Not Set";
        let trakteer = trakteers ? trakteers : "Not Set";
        let bagis = bagi ? bagi : "Not Set";
        let saweria = sawerias ? sawerias : "Not Set";

        if (world || owner || botName || sawerias || trakteers || bagi) {
            await depo.findOneAndUpdate(
                    {},
                    { $set: { world: worlds, owner: owners, botName: botnames, saweria: saweria, Trakteer: trakteer, BagiBagi: bagis }},
                    { upsert: true, new: true }
                )
                .then(async (d) => {
                    await interaction.reply({
                        content: `**Successfully Set Deposit**\n- With World: **${worlds}**\n- With Owner: **${owners}**\n- With Bot Name: **${botnames}**\n- Set Link Saweria: **${saweria}**\n- Set Link Trakteer: **${trakteer}**\n- Set Link Bagi-Bagi: **${bagis}**`,
                        ephemeral: true
                    }).catch((err) => console.error(err));
                })
                .catch((e) => console.error(e));
        } else {
            return await interaction.reply({
                content: `*Choose 1 option to set you world depo! ${Salah}*`,
                ephemeral: true
            });
        }
    }
}