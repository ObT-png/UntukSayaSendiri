let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let setchannel = require("../../Schema/AllSettingChannel.js");
let { Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'setchannel',
    description: "Set Channel",
    accessableby: "admin",
    options: [
        {
            name: "testimoni",
            description: "Set Channel For Testimoni",
            type: ApplicationCommandOptionType.Channel,
            required: true
        },
        {
            name: "autostock",
            description: "Set Channel For Auto Stock",
            type: ApplicationCommandOptionType.Channel,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let data1 = interaction.options.getChannel("testimoni");
        let data2 = interaction.options.getChannel("autostock");
        let ChanelID = interaction.guild.channels.cache.get(data1.id);
        let ChanelID1 = interaction.guild.channels.cache.get(data2.id);
        if (!ChanelID.viewable && !ChanelID1.viewable) return interaction.reply({
            content: `*The provided channel is not visible to me! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await setchannel.findOneAndUpdate(
            {},
            { $set: { ChanelTesti: ChanelID, ChannelAutoStock: ChanelID1 } },
            { upsert: true, new: true }
        )
        .then(async (res) => {
            await interaction.reply({
                content:`*Successffully Set Chanel Testimoni To **${data1} ${Benar}**\nSuccessffully Set Chanel Auto Stock To **${data2} ${Benar}***`,
                ephemeral: true
            }).catch((err) => console.error(err));
        })
        .catch((e) => console.error(e));
    }
}