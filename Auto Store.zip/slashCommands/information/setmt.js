let {
    Client,
    CommandInteraction,
} = require("discord.js");
let mt = require("../../Schema/mt.js");
let { Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'setmt',
    description: "set Your Bo To Mt",
    accessableby: "admin",
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        await mt.findOne({})
            .then(async (d) => {
                if (d) {
                    d.mt = !d?.mt;
                    await d
                        .save()
                        .then(async (d1) => {
                            await interaction.reply({
                                content:`${d?.mt ? `*Bot Maintenance ${Salah}*` : `*Done Maintenance ${Benar}*`}`,
                                ephemeral: true
                            }).catch((err) => console.error(err));
                        })
                        .catch(console.error);
                } else {
                    await new mt({ mt: !d?.mt })
                        .save()
                        .then(async (d) => {
                            await interaction.reply({
                                content:`${d?.mt ? `*Bot Maintenance ${Salah}*` : `*Done Maintenance ${Benar}*`}`,
                                ephemeral: true
                            }).catch((err) => console.error(err));
                        })
                        .catch(console.error);
                }
            })
            .catch(console.error);
    }
}