let {
    EmbedBuilder,
    Client,
    CommandInteraction,
    ChannelType,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ApplicationCommandOptionType,
} = require("discord.js");
let list = require("../../Schema/list.js");
let shop = require("../../Schema/shop.js");
let path = require("path");
let request = require("request");
let { Loading, Benar, Salah } = require("../../config/configEmoji.json");
module.exports = {
    name: 'addstock',
    description: "add Stock For Stock",
    accessableby: "admin",
    options: [
        {
            name: "code",
            description: "What Code For Add Stock?",
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: "item",
            description: "Write Data",
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: "file",
            description: "Upload Your file",
            type: ApplicationCommandOptionType.Attachment,
            required: false
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let itemo = interaction.options.getString("item");
        let filo = interaction.options.getAttachment("file");
        let code = interaction.options.getString("code");
        let getCode = await list
            .findOne({ code: code })
            .then((d) => {
                return d;
            })
            .catch(console.error);

        let typo = await list
            .findOne({ code: code })
            .then((d) => {
                return d?.type
            })
            .catch(console.error);

        if (!getCode) return interaction.reply({
            content: `*Product With That Code Doesn't Exist ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        if (filo && itemo) return interaction.reply({
            content: `*Choose 1 option only sir! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        if (filo) {
            let getf = path.extname(filo.name);
            let sal = [".txt", ".lua", ".js"]

            if (!sal.includes(getf)) return interaction.reply({
                content: `***Error!!!\nYour File Is: ${getf}\nOnly file .txt or .lua or .js Can add For It!** ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));
        }

        try {
            if (filo || itemo) {
                await interaction.reply({
                    content: `***Proccessing Your Data Into Database** ${Loading}*`,
                    ephemeral: true
                }).catch((err) => console.error(err));

                if (filo) {
                    let filos = interaction.options.getAttachment("file");
                    if (typo.includes("script") || typo.includes("df")) {
                        request(filos.url, async (err, res, body) => {
                            if (err) return console.error(err);
                            let script = body;
                            let items = body.split("|");
                            if (typo.includes("df")) {
                                for (let item of items) {
                                    let getdata = await shop
                                        .findOne({ data: item })
                                        .then((res) => {
                                            return res;
                                        })
                                        .catch(console.error);
                                        
                                    if (!getdata) {
                                        await new shop({
                                            code: code,
                                            data: item,
                                        })
                                            .save()
                                            .then((d) => {
                                                console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                            })
                                            .catch(console.error);
                                    } else {
                                        await interaction.followUp({
                                            content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*`,
                                            ephemeral: true
                                        }).catch((err) => console.error(err));
                                        console.log(`[COMMANDS]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                                    }
                                }

                                await interaction.followUp({
                                    content: `***Successfully Added Item For Dirtfarm Into Database ${Benar}***`,
                                    ephemeral: true
                                }).catch((err) => console.error(err));
                            } else if (typo.includes("script")) {
                                await new shop({
                                    code: code,
                                    data: script,
                                })
                                    .save()
                                    .then((d) => {
                                        console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: \n${script}`.green.bold);
                                    })
                                    .catch(console.error);

                                await interaction.followUp({
                                    content: `***Successfully Added Script Into Database ${Benar}***`,
                                    ephemeral: true
                                }).catch((err) => console.error(err));
                            }
                        });
                    } else {
                        request(filos.url, async (err, res, body) => {
                            if (err) return console.error(err);
                            let items = body.split(/[\n\r\s]+/);
                            if (items.length == 0) return interaction.followUp({ content: `*No Item In This File!*`, ephemeral: true })
                            for (let item of items) {
                                let getdata = await shop
                                    .findOne({ data: item })
                                    .then((res) => {
                                        return res;
                                    })
                                    .catch(console.error);

                                if (!getdata) {
                                    await new shop({
                                        code: code,
                                        data: item,
                                    })
                                        .save()
                                        .then((d) => {
                                            console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                        })
                                        .catch(console.error);
                                } else {
                                    await interaction.followUp({
                                        content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*`,
                                        ephemeral: true
                                    }).catch((err) => console.error(err));
                                    console.log(`[COMMANDS]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                                }
                            }
                            await interaction.followUp({
                                content: `***Write File Succesffully And Added Into the database! ${Benar}***`,
                                ephemeral: true
                            }).catch((err) => console.error(err));
                        });
                    }
                } else {
                    let items = interaction.options.getString("item").split(/\s+/);
                    let itema = interaction.options.getString("item").split("|");
                    let itemi = interaction.options.getString("item");
                    if (typo.includes("script") || typo.includes("df")) {
                        if (typo.includes("df")) {
                            for (let item of itema) {
                                let getdata = await shop
                                    .findOne({ data: item })
                                    .then((res) => {
                                        return res;
                                    })
                                    .catch(console.error);

                                if (!getdata) {
                                    await new shop({
                                        code: code,
                                        data: item,
                                    })
                                        .save()
                                        .then((d) => {
                                            console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                        })
                                        .catch(console.error);
                                } else {
                                    await interaction.followUp({
                                        content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*`,
                                        ephemeral: true
                                    }).catch((err) => console.error(err));
                                    console.log(`[COMMANDS]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                                }
                            };
                            await interaction.followUp({
                                content: `***Successfully Added Item For Dirtfarm Into Database ${Benar}***`,
                                ephemeral: true
                            }).catch((err) => console.error(err));
                        } else if (typo.includes("script")) {
                            await new shop({
                                code: code,
                                data: itemi,
                            })
                                .save()
                                .then((d) => {
                                    console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: \n${itemi}`.green.bold);
                                })
                                .catch(console.error);

                            await interaction.followUp({
                                content: `***Successfully Added Script Into Database ${Benar}***`,
                                ephemeral: true
                            }).catch((err) => console.error(err));
                        }
                    } else {
                        for (let item of items) {
                            let getdata = await shop
                                .findOne({ data: item })
                                .then((res) => {
                                    return res;
                                })
                                .catch(console.error);

                            if (!getdata) {
                                await new shop({
                                    code: code,
                                    data: item,
                                })
                                    .save()
                                    .then((d) => {
                                        console.log(`[COMMANDS]`.bgMagenta.bold, `Adding Your Data: ${item}`.green.bold);
                                    })
                                    .catch(console.error);
                            } else {
                                await interaction.followUp({
                                    content: `*This Item Already Has Exis't In MongoDB: **${item}** ${Salah}*`,
                                    ephemeral: true
                                }).catch((err) => console.error(err));
                                console.log(`[COMMANDS]`.bgMagenta.bold, `Your Data Already Have In Mongodb: ${item}`.red.bold);
                            }
                        };
                        await interaction.followUp({
                            content: `***The All Item Has Been Added Into Database ${Benar}***`,
                            ephemeral: true
                        }).catch((err) => console.error(err));
                        console.log(`[COMMANDS]`.bgMagenta.bold, `Successfully Adding Stock`.bgBlue.bold);
                    }
                }
            } else {
                await interaction.reply({
                    content: "***Error!!!\nNot Have Item Or File In Your Send!*** " + Salah,
                    ephemeral: true
                }).catch((err) => console.error(err));
            }
        } catch (error) {
            console.error(error);
            await interaction.followUp({
                content: `*Ada Yang Salah!*`,
                ephemeral: true
            }).catch((err) => console.error(err));
        }
    }
}