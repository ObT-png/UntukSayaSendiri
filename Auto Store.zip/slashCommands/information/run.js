let client = require('../../index.js');
let {
    ActivityType,
    ButtonStyle,
    ActionRowBuilder,
    EmbedBuilder,
    MessageEmbed,
    ButtonBuilder,
    ApplicationCommandOptionType
} = require("discord.js");
let shop = require("../../Schema/shop.js");
let channelo = require("../../Schema/AllSettingChannel.js");
let mt = require("../../Schema/mt.js");
let order = require("../../Schema/order.js");
let depo = require("../../Schema/depo.js");
let Price = require("../../Schema/price.js");
let list = require("../../Schema/list.js");
let Bal = require("../../Schema/balance.js");
let { Benar, ARROW, Salah, Megaphone, WL, DL, BGL, CROWN, Duit, EARTH, BOT, imageUrl, COLOR, Watermark, Kotak } = require("../../config/configEmoji.json");
let Discount = require('../../Schema/discount.js');

module.exports = {
    name: 'run',
    description: "sending realtime product",
    accessableby: "admin",
    options: [
        {
            name: "channel",
            description: "Select Your Server To Send Realtime!",
            type: ApplicationCommandOptionType.Channel,
            required: true
        },
        {
            name: "delay",
            description: "Delay For Seconds/Detik",
            type: ApplicationCommandOptionType.Number,
            required: true
        }
    ],
    /** 
     * @param {Client} client 
     * @param {CommandInteraction} interaction
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        let delay = interaction.options.getNumber("delay");
        let channel = interaction.options.getChannel("channel");
        let ChanelID = interaction.guild.channels.cache.get(`${channel.id}`);

        if (!ChanelID.viewable) {
            return interaction.reply({
                content: `*The provided channel is not visible to me! ${Salah}*`,
                ephemeral: true
            }).catch((err) => console.error(err));
        }

        if (delay < 30 || delay > 120) return interaction.reply({
            content: `*Minimum Delay For Realtime Is 30 Seconds And Max Delay 120 Seconds/2 Minutes ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        let chanel = await channelo
            .findOne({})
            .then((d) => {
                return d?.ChannelStock;
            })
            .catch(console.error());

        let getCodesa = await list
            .find({})
            .then((res) => {
                return res;
            })
            .catch(console.error);

        if (getCodesa.length < 1) return interaction.reply({
            content: `*/addproduct first before use this commands! ${Salah}*`,
            ephemeral: true
        }).catch((err) => console.error(err));

        await interaction.reply({
            content: `*Started Editing The Realtime Stock Delay **${delay}s ${Benar}***`,
            ephemeral: true
        }).catch((err) => console.error(err));

        let sat = await channel.send({
            content: `*Started Editing The Realtime Stock Delay **${delay}s ${Benar}***`
        }).catch((err) => console.error(err));

        await channelo.findOneAndUpdate(
            {},
            { $set: { ChannelStock: ChanelID, MessageID: sat.id, Delay: delay } },
            { upsert: true, new: true }
        );

        try {
            if (!chanel) {
                setInterval(async () => {
                    let MT = await mt
                        .findOne({})
                        .then((d) => {
                            return d?.mt;
                        })
                        .catch(console.error);

                    let orderan = await order
                        .findOne({})
                        .then((d) => {
                            return d?.Order;
                        })
                        .catch((e) => console.error(e));
                    
                    let deposit = await depo
                        .findOne({})
                        .then((d) => {
                            return d?.ratedl;
                        })
                        .catch((e) => console.error(e));

                    let getCodes = await list
                        .find({})
                        .then((res) => {
                            return res;
                        })
                        .catch(console.error);
                    if (getCodes.length < 1) return;
                    let format = `<t:${Math.floor(new Date().getTime() / 1000)}:R>`;
                    let text = "";
                    let sold = "";
                    let solding = 0;
                    for (let i = 0; i < getCodes.length; i++) {
                        let code = getCodes[i];
                        let stock = await shop
                            .find({ code: code.code })
                            .then((res) => {
                                return res;
                            })
                            .catch(console.error);
                        let price = await Price.findOne({ code: code.code })
                            .then((res) => {
                                return res;
                            })
                            .catch(console.error);
                        let discount = await Discount.findOne({ code: code.code })
                            .then((res) => {
                                return res;
                            })
                            .catch(console.error);
                        let haveStock = stock.length > 0;
                        let emojis = haveStock ? Benar : Salah;
                        let stockMessage = haveStock ? `${stock.length}` : "";
                        solding += Number(code.sold);
                        sold += `${ARROW} ${code.name} : **${code.sold}**\n`;
                        text += `**--------------------------------------------**\n` +
                            `${CROWN} **${code.name}** ${CROWN}\n` +
                            `${ARROW} Code: **${code.code}**\n` +
                            `${code?.desc != "Not Set" ? `${ARROW} Description: **${code?.desc}**\n` : ""}` +
                            `${ARROW} Stock: **${stockMessage} ${emojis}**\n` +
                            `${ARROW} Price: **${discount ? `${price ? `${Math.floor(discount.price / 10000) != 0 ? ` ${Math.floor(discount.price / 10000)} ${BGL}` : ``}${Math.floor((discount.price % 10000) / 100) != 0 ? ` ${Math.floor((discount.price % 10000) / 100)} ${DL}` : ``}${discount.price % 100 != 0 ? ` ${discount.price % 100} ${WL}` : ``} *(${((price.price - discount.price) / price.price) * 100}%)*` : "Not Set Yet"}` : `${price ? `${Math.floor(price.price / 10000) != 0 ? ` ${Math.floor(price.price / 10000)} ${BGL}` : ``}${Math.floor((price.price % 10000) / 100) != 0 ? ` ${Math.floor((price.price % 10000) / 100)} ${DL}` : ``}${price.price % 100 != 0 ? ` ${price.price % 100} ${WL}` : ``}` : "Not Set Yet"}`}**\n`;
                    }

                    let embed = new EmbedBuilder()
                        .setTitle(`${Megaphone} PRODUCT LIST ${Megaphone}`)
                        .setDescription(`**Last Update: ${format}**\n${text}`)
                        .setColor(COLOR)
                        .setImage(imageUrl);

                    let embed1 = new EmbedBuilder()
                        .setTitle(`${CROWN} Statistic Stock ${CROWN}`)
                        .setDescription(`*${ARROW} Total Order : **${orderan}**\n${ARROW} Total Purchase : **${solding}**\n${ARROW} RATE DL : **${deposit ? `Rp${new Intl.NumberFormat().format(deposit * 100)}**/${DL}` : `Not Set Yet`}*\n**Purchases Product:**\n${sold}`)
                        .setColor(COLOR)
                        .setImage(imageUrl);

                    let row = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel("Buy")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<:emoji_72:1210797404731740181>")
                            .setCustomId("Howmanys"),
                        new ButtonBuilder()
                            .setLabel("Set GrowID")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:book431:1248246276022206485>")
                            .setCustomId("growid23"),
                        new ButtonBuilder()
                            .setLabel("Balance")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:faq:1174339877333119068>")
                            .setCustomId("balance1"),
                        new ButtonBuilder()
                            .setLabel("Deposit World")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:world:1174338186189733899>")
                            .setCustomId("deposit")
                    );

                    let rowmt = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setLabel("Buy Product")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<:emoji_72:1210797404731740181>")
                            .setDisabled(true)
                            .setCustomId("Howmanys"),
                        new ButtonBuilder()
                            .setLabel("Set GrowID")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:book431:1248246276022206485>")
                            .setDisabled(true)
                            .setCustomId("growid23"),
                        new ButtonBuilder()
                            .setLabel("Balance")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:faq:1174339877333119068>")
                            .setDisabled(true)
                            .setCustomId("balance1"),
                        new ButtonBuilder()
                            .setLabel("Deposit World")
                            .setStyle(ButtonStyle.Secondary)
                            .setEmoji("<a:world:1174338186189733899>")
                            .setDisabled(true)
                            .setCustomId("deposit")
                    );

                    if (MT) {
                        await sat.edit({
                            content: `**${Watermark}**`,
                            embeds: [embed1, embed],
                            components: [rowmt]
                        }).catch((err) => console.error(err));
                    } else {
                        await sat.edit({
                            content: `**${Watermark}**`,
                            embeds: [embed1, embed],
                            components: [row]
                        }).catch((err) => console.error(err));
                    }
                }, delay * 1000);
            }
        } catch (err) {
            console.error(err);
        }
    }
}